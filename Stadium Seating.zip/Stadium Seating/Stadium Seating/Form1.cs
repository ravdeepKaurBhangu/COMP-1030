﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Stadium_Seating
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string cA, cB, cC;
            cA = textBox1.Text;//fetched the sring value
            cB = textBox2.Text;
            cC = textBox3.Text;

            double classA, classB, classC, Total;

            classA = double.Parse(cA); //changed to duble
            classB = double.Parse(cB);
            classC = double.Parse(cC);

            Total = classA*10 + classB*20 + classC*30;

            double cla1, cla2, cla3; //extracted value for textboxes 4,5, and 6. 
            cla1 = classA * 10;
            textBox4.Text = cla1.ToString("C");

          
            cla2 = classB * 20;
            textBox5.Text = cla2.ToString("C");

            
            cla3 = classC * 30;
            textBox6.Text = cla3.ToString("C");

         
            textBox7.Text = Total.ToString("C");


            //MessageBox.Show("total is " + Total);



        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";

            //when clear button is clicked the content from all the text boxes would go awaya as there is no content in between the ""
        }
    }

}